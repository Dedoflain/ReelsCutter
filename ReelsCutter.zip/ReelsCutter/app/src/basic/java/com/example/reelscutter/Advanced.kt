package com.example.reelscutter

import android.content.Context

/**
 * ЗАГЛУШКА. Используется, если полная сборка с режимом «видео снизу» и хромакеем не удалась.
 * Приложение остаётся рабочим, но этих двух функций в нём нет.
 */
object Advanced {
    const val available = false

    suspend fun exportComposite(context: Context, p: CompositeParams) {
        throw UnsupportedOperationException(
            "В этой сборке нет режимов «видео снизу» и хромакея (полная сборка не прошла проверку)."
        )
    }
}
