package com.example.reelscutter

data class Word(val text: String, val start: Double, val end: Double)

data class Cue(val startUs: Long, val endUs: Long, val text: String)

object Planner {

    /** Делит видео на клипы примерно по clipSec секунд, стараясь резать между словами. */
    fun plan(durationSec: Double, clipSec: Int, words: List<Word>): List<Pair<Double, Double>> {
        val result = mutableListOf<Pair<Double, Double>>()
        var start = 0.0
        while (start < durationSec - 1.0) {
            var end = minOf(start + clipSec, durationSec)
            if (end < durationSec) {
                val snap = words.lastOrNull { it.end <= end && it.end >= end - 5.0 }
                if (snap != null) end = minOf(snap.end + 0.15, durationSec)
            }
            if (end <= start) end = minOf(start + clipSec, durationSec)
            result.add(start to end)
            start = end
        }
        // Короткий хвост (< 5 сек) приклеиваем к предыдущему клипу
        if (result.size > 1 && result.last().second - result.last().first < 5.0) {
            val tail = result.removeAt(result.lastIndex)
            val prev = result.removeAt(result.lastIndex)
            result.add(prev.first to tail.second)
        }
        return result
    }

    /** Субтитры для клипа [s, e]: по 3 слова, время относительно начала клипа. */
    fun cues(words: List<Word>, s: Double, e: Double): List<Cue> {
        val inClip = words.filter { it.start >= s - 0.05 && it.end <= e + 0.2 }
        val chunks = mutableListOf<List<Word>>()
        var cur = mutableListOf<Word>()
        for (w in inClip) {
            if (cur.isNotEmpty() && (cur.size >= 3 || w.start - cur.last().end > 0.8)) {
                chunks.add(cur); cur = mutableListOf()
            }
            cur.add(w)
        }
        if (cur.isNotEmpty()) chunks.add(cur)

        return chunks.mapIndexed { i, c ->
            val startUs = ((c.first().start - s) * 1_000_000).toLong().coerceAtLeast(0)
            var endUs = ((c.last().end - s) * 1_000_000).toLong()
            val nextStart = chunks.getOrNull(i + 1)
                ?.let { ((it.first().start - s) * 1_000_000).toLong() }
            endUs = if (nextStart != null) minOf(nextStart, endUs + 400_000) else endUs + 400_000
            Cue(startUs, endUs, c.joinToString(" ") { it.text })
        }
    }
}
