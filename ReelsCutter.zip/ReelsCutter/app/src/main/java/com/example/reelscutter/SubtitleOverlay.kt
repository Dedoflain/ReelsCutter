package com.example.reelscutter

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import kotlin.math.ceil
import kotlin.math.max

/**
 * Субтитры, нарисованные самим приложением: свой шрифт, цвет и чёрная обводка.
 * Размеры в пикселях итогового кадра (1 пиксель текста = 1 пиксель видео).
 */
class SubtitleOverlay(
    private val cues: List<Cue>,
    private val typeface: Typeface,
    private val textPx: Float,
    private val color: Int,
    private val maxWidthPx: Int,
    anchorY: Float,
) : BitmapOverlay() {

    private val cache = HashMap<Int, Bitmap>()
    private val empty: Bitmap = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888)
    private val settings: OverlaySettings = OverlaySettings.Builder()
        .setBackgroundFrameAnchor(0f, anchorY) // -1 = низ кадра, +1 = верх
        .build()

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val idx = cues.indexOfFirst { presentationTimeUs >= it.startUs && presentationTimeUs < it.endUs }
        if (idx < 0) return empty
        return cache.getOrPut(idx) { render(cues[idx].text) }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings

    private fun render(text: String): Bitmap {
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = this@SubtitleOverlay.typeface
            textSize = textPx
            color = this@SubtitleOverlay.color
        }
        val stroke = textPx * 0.16f
        val pad = ceil(stroke).toInt() + 2
        val avail = max(maxWidthPx - 2 * pad, 50)

        val layout = StaticLayout.Builder.obtain(text, 0, text.length, paint, avail)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .build()

        var widest = 0f
        for (i in 0 until layout.lineCount) widest = max(widest, layout.getLineWidth(i))
        val w = ceil(widest).toInt()
        val bmp = Bitmap.createBitmap(w + 2 * pad, layout.height + 2 * pad, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        // строки выровнены по центру блока шириной avail, сдвигаем так, чтобы текст лёг вплотную к левому краю
        canvas.translate(pad - (avail - w) / 2f, pad.toFloat())

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = stroke
        paint.strokeJoin = Paint.Join.ROUND
        paint.color = Color.BLACK
        layout.draw(canvas)

        paint.style = Paint.Style.FILL
        paint.color = color
        layout.draw(canvas)
        return bmp
    }
}
