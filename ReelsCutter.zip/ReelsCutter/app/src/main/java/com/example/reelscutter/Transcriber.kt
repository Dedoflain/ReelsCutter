package com.example.reelscutter

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File

/** Офлайн-распознавание речи (Vosk). Модель лежит в assets/model-ru. */
class Transcriber(private val context: Context) {

    private var model: Model? = null

    private fun ensureModel(): Model {
        model?.let { return it }
        val dir = File(context.filesDir, "model-ru")
        if (!File(dir, "conf").exists()) {
            val tmp = File(context.filesDir, "model-ru.tmp")
            tmp.deleteRecursively()
            copyAssets("model-ru", tmp)
            dir.deleteRecursively()
            tmp.renameTo(dir)
        }
        return Model(dir.absolutePath).also { model = it }
    }

    private fun copyAssets(path: String, target: File) {
        val children = context.assets.list(path)
        if (children.isNullOrEmpty()) {
            target.parentFile?.mkdirs()
            context.assets.open(path).use { i -> target.outputStream().use { o -> i.copyTo(o) } }
        } else {
            target.mkdirs()
            for (c in children) copyAssets("$path/$c", File(target, c))
        }
    }

    fun transcribe(uri: Uri, durationSec: Double, onProgress: (Float) -> Unit): List<Word> {
        val rec = Recognizer(ensureModel(), 16000f)
        rec.setWords(true)
        val words = mutableListOf<Word>()

        fun collect(json: String) {
            val arr = JSONObject(json).optJSONArray("result") ?: return
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                words.add(Word(o.getString("word"), o.getDouble("start"), o.getDouble("end")))
            }
        }

        try {
            AudioDecoder.decode(context, uri) { pcm, ptsUs ->
                if (rec.acceptWaveForm(pcm, pcm.size)) collect(rec.result)
                onProgress((ptsUs / 1_000_000.0 / durationSec).coerceIn(0.0, 1.0).toFloat())
            }
            collect(rec.finalResult)
        } finally {
            rec.close()
        }
        return words
    }
}
