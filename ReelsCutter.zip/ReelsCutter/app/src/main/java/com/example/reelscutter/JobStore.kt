package com.example.reelscutter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Meta(
    val durationSec: Double,
    val bitrate: Int,
    val width: Int,      // размеры кадра с учётом поворота
    val height: Int,
    val bottomDurSec: Double,
    val ovDurSec: Double = 0.0,
    val ovWidth: Int = 0,
    val ovHeight: Int = 0,
)

/**
 * Задание на обработку. Сохраняется на диск после каждого этапа:
 * если Android убьёт процесс, работа продолжится с того же места, а не с нуля.
 */
class WorkJob(var source: String, var settings: Prefs.Settings) {
    var meta: Meta? = null
    var words: List<Word>? = null
    var clips: List<Pair<Double, Double>>? = null
    var done = 0
    var attempts = 0
    var warning = ""

    fun toJson(): JSONObject = JSONObject().apply {
        put("source", source)
        put("settings", settings.toJson())
        put("done", done)
        put("attempts", attempts)
        put("warning", warning)
        meta?.let {
            put("meta", JSONObject().apply {
                put("dur", it.durationSec); put("br", it.bitrate)
                put("w", it.width); put("h", it.height); put("bdur", it.bottomDurSec)
                put("odur", it.ovDurSec); put("ow", it.ovWidth); put("oh", it.ovHeight)
            })
        }
        words?.let { list ->
            put("words", JSONArray().apply {
                list.forEach { put(JSONArray().put(it.text).put(it.start).put(it.end)) }
            })
        }
        clips?.let { list ->
            put("clips", JSONArray().apply { list.forEach { put(JSONArray().put(it.first).put(it.second)) } })
        }
    }

    companion object {
        fun fromJson(j: JSONObject): WorkJob {
            val w = WorkJob(j.getString("source"), Prefs.Settings.fromJson(j.getJSONObject("settings")))
            w.done = j.optInt("done", 0)
            w.attempts = j.optInt("attempts", 0)
            w.warning = j.optString("warning", "")
            j.optJSONObject("meta")?.let {
                w.meta = Meta(it.getDouble("dur"), it.getInt("br"), it.getInt("w"), it.getInt("h"), it.optDouble("bdur", 0.0),
                    it.optDouble("odur", 0.0), it.optInt("ow", 0), it.optInt("oh", 0))
            }
            j.optJSONArray("words")?.let { a ->
                w.words = List(a.length()) { i ->
                    val x = a.getJSONArray(i)
                    Word(x.getString(0), x.getDouble(1), x.getDouble(2))
                }
            }
            j.optJSONArray("clips")?.let { a ->
                w.clips = List(a.length()) { i ->
                    val x = a.getJSONArray(i)
                    x.getDouble(0) to x.getDouble(1)
                }
            }
            return w
        }
    }
}

object JobStore {
    private fun file(c: Context) = File(c.filesDir, "job.json")

    fun load(c: Context): WorkJob? = try {
        val f = file(c)
        if (f.exists()) WorkJob.fromJson(JSONObject(f.readText())) else null
    } catch (_: Exception) {
        null
    }

    @Synchronized
    fun save(c: Context, job: WorkJob) {
        val tmp = File(c.filesDir, "job.json.tmp")
        tmp.writeText(job.toJson().toString())
        if (!tmp.renameTo(file(c))) {
            file(c).writeText(tmp.readText())
            tmp.delete()
        }
    }

    @Synchronized
    fun clear(c: Context) {
        file(c).delete()
    }
}
