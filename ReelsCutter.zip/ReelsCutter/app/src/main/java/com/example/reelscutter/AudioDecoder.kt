package com.example.reelscutter

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Декодирует звук видео и отдаёт PCM 16 kHz, моно, 16 bit (формат для Vosk) кусками. */
object AudioDecoder {

    private class Resampler {
        private var pos = 0.0
        private var carry: Short = 0

        fun process(input: ShortArray, n: Int, rate: Int): ByteArray {
            val step = rate / 16000.0
            val out = ByteBuffer.allocate(((n / step).toInt() + 4) * 2).order(ByteOrder.LITTLE_ENDIAN)
            while (pos < n - 1) {
                val i = Math.floor(pos).toInt()
                val frac = pos - i
                val a = if (i < 0) carry.toInt() else input[i].toInt()
                val b = input[i + 1].toInt()
                out.putShort((a + (b - a) * frac).toInt().toShort())
                pos += step
            }
            pos -= n
            carry = input[n - 1]
            return out.array().copyOf(out.position())
        }
    }

    fun decode(context: Context, uri: Uri, onPcm: (ByteArray, Long) -> Unit) {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        var track = -1
        for (i in 0 until extractor.trackCount) {
            val mime = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)
            if (mime?.startsWith("audio/") == true) { track = i; break }
        }
        if (track < 0) { extractor.release(); return }

        extractor.selectTrack(track)
        val format = extractor.getTrackFormat(track)
        val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
        var rate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val resampler = Resampler()
        val info = MediaCodec.BufferInfo()

        try {
            codec.configure(format, null, null, 0)
            codec.start()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!inputDone) {
                    val i = codec.dequeueInputBuffer(10_000)
                    if (i >= 0) {
                        val buf = codec.getInputBuffer(i)!!
                        val n = extractor.readSampleData(buf, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10_000)
                when {
                    o >= 0 -> {
                        val ob = codec.getOutputBuffer(o)!!
                        if (info.size > 0) {
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                            val frames = sb.remaining() / channels
                            if (frames > 1) {
                                val mono = ShortArray(frames)
                                for (f in 0 until frames) {
                                    var sum = 0
                                    for (c in 0 until channels) sum += sb.get(f * channels + c)
                                    mono[f] = (sum / channels).toShort()
                                }
                                val pcm = resampler.process(mono, frames, rate)
                                if (pcm.isNotEmpty()) onPcm(pcm, info.presentationTimeUs)
                            }
                        }
                        codec.releaseOutputBuffer(o, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                    o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val f = codec.outputFormat
                        rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            extractor.release()
        }
    }
}
