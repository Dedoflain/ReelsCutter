package com.example.reelscutter

import android.content.ContentValues
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.media.MediaCodecInfo
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object ClipExporter {

    /** Запускает Transformer на главном потоке и ждёт результат. begin() должен вызвать transformer.start(...). */
    suspend fun runTransformer(context: Context, bitrate: Int, begin: (Transformer) -> Unit) =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Unit> { cont ->
                val encoderFactory = DefaultEncoderFactory.Builder(context)
                    .setRequestedVideoEncoderSettings(
                        VideoEncoderSettings.Builder()
                            .setBitrate(bitrate)
                            .setBitrateMode(MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                            .build()
                    )
                    .build()

                val transformer = Transformer.Builder(context)
                    .setVideoMimeType(MimeTypes.VIDEO_H264)
                    .setAudioMimeType(MimeTypes.AUDIO_AAC)
                    .setEncoderFactory(encoderFactory)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(Unit)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            val details = exportException.cause?.message ?: exportException.message
                            if (cont.isActive) {
                                cont.resumeWithException(
                                    RuntimeException("${exportException.errorCodeName}: $details", exportException)
                                )
                            }
                        }
                    })
                    .build()

                cont.invokeOnCancellation {
                    Handler(Looper.getMainLooper()).post {
                        try { transformer.cancel() } catch (_: Exception) {}
                    }
                }
                try {
                    begin(transformer)
                } catch (e: Exception) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
        }

    /** Вырезает [startMs, endMs] без изменения размера кадра. Субтитры (если есть) вшиваются в картинку. */
    suspend fun export(
        context: Context,
        source: Uri,
        startMs: Long,
        endMs: Long,
        overlay: BitmapOverlay?,
        bitrate: Int,
        outFile: File,
    ) {
        runTransformer(context, bitrate) { transformer ->
            val clip = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
            val item = MediaItem.Builder().setUri(source).setClippingConfiguration(clip).build()

            val video = mutableListOf<Effect>()
            if (overlay != null) {
                video.add(OverlayEffect(listOf<TextureOverlay>(overlay)))
            }
            val edited = EditedMediaItem.Builder(item)
                .setEffects(Effects(listOf(), video))
                .build()
            transformer.start(edited, outFile.absolutePath)
        }
    }

    /** Копирует готовый файл в галерею: Movies/ReelsCutter. Пока идёт копирование, файл скрыт. */
    fun saveToGallery(context: Context, file: File, displayName: String) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ReelsCutter")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Не удалось создать файл в галерее")
        try {
            resolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
            val done = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
            resolver.update(uri, done, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        } finally {
            file.delete()
        }
    }
}
