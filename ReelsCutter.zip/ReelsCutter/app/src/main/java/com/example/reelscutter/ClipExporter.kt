package com.example.reelscutter

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.net.Uri
import android.provider.MediaStore
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Размер шрифта субтитров. Если на видео текст слишком мелкий/крупный, поменяйте это число. */
private const val SUBTITLE_SIZE_PX = 56

/** Субтитры, которые вшиваются в картинку по таймкодам. */
private class SubtitleOverlay(private val cues: List<Cue>) : TextOverlay() {
    private val settings = OverlaySettings.Builder()
        .setBackgroundFrameAnchor(0f, -0.55f) // ниже центра; -1 = самый низ
        .build()

    override fun getText(presentationTimeUs: Long): SpannableString {
        val text = cues.firstOrNull { presentationTimeUs >= it.startUs && presentationTimeUs < it.endUs }?.text
        val s = SpannableString(text ?: " ")
        val f = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        s.setSpan(ForegroundColorSpan(Color.WHITE), 0, s.length, f)
        s.setSpan(AbsoluteSizeSpan(SUBTITLE_SIZE_PX), 0, s.length, f)
        s.setSpan(StyleSpan(android.graphics.Typeface.BOLD), 0, s.length, f)
        if (text != null) s.setSpan(BackgroundColorSpan(0x99000000.toInt()), 0, s.length, f)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings = settings
}

object ClipExporter {

    /** Вырезает [startMs, endMs], кадрирует в 9:16 и вшивает субтитры. Вызывать из корутины. */
    suspend fun export(
        context: Context,
        source: Uri,
        startMs: Long,
        endMs: Long,
        cues: List<Cue>,
        outFile: File,
    ) = withContext(Dispatchers.Main) {
        suspendCancellableCoroutine<Unit> { cont ->
            val clip = MediaItem.ClippingConfiguration.Builder()
                .setStartPositionMs(startMs)
                .setEndPositionMs(endMs)
                .build()
            val item = MediaItem.Builder().setUri(source).setClippingConfiguration(clip).build()

            val video = mutableListOf<Effect>(
                Presentation.createForAspectRatio(9f / 16f, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
            )
            if (cues.isNotEmpty()) {
                video.add(OverlayEffect(ImmutableList.of(SubtitleOverlay(cues))))
            }
            val edited = EditedMediaItem.Builder(item)
                .setEffects(Effects(listOf(), video))
                .build()

            val transformer = Transformer.Builder(context)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                        if (cont.isActive) cont.resume(Unit)
                    }

                    override fun onError(
                        composition: Composition,
                        exportResult: ExportResult,
                        exportException: ExportException,
                    ) {
                        if (cont.isActive) cont.resumeWithException(exportException)
                    }
                })
                .build()

            cont.invokeOnCancellation { transformer.cancel() }
            transformer.start(edited, outFile.absolutePath)
        }
    }

    /** Копирует готовый файл в галерею: Movies/ReelsCutter. */
    fun saveToGallery(context: Context, file: File, displayName: String) {
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ReelsCutter")
        }
        val uri = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: error("Не удалось создать файл в галерее")
        context.contentResolver.openOutputStream(uri)!!.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        file.delete()
    }
}
