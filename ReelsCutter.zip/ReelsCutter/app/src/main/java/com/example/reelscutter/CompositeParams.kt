package com.example.reelscutter

import android.net.Uri
import androidx.media3.effect.BitmapOverlay
import java.io.File

/** Всё, что нужно для сборки составного клипа: основное видео + видео снизу + наложение с хромакеем. */
class CompositeParams(
    val main: Uri,
    val mainStartMs: Long,
    val mainEndMs: Long,
    val outW: Int,
    val outH: Int,
    val stacked: Boolean,
    val topH: Int,
    val fillTop: Boolean,
    val bottom: Uri?,
    val bottomStartMs: Long,
    val bottomEndMs: Long,       // -1: не обрезать, зациклить целиком
    val overlay: Uri?,
    val ovStartMs: Long,
    val ovEndMs: Long,           // -1: не обрезать, зациклить целиком
    val ovW: Int,
    val ovH: Int,
    val ovAnchorX: Float,        // центр наложения в координатах кадра от -1 до 1
    val ovAnchorY: Float,
    val chroma: Boolean,
    val keyColor: Int,
    val tolerance: Int,
    val softness: Int,
    val spill: Int,
    val subtitles: BitmapOverlay?,
    val bitrate: Int,
    val out: File,
)
