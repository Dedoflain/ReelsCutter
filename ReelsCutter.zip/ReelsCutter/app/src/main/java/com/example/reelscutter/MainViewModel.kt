package com.example.reelscutter

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var video by mutableStateOf<Uri?>(null)
    var clipSec by mutableStateOf(60f)
    var subtitles by mutableStateOf(true)
    var status by mutableStateOf("Выберите видео")
    var progress by mutableStateOf(0f)
    var busy by mutableStateOf(false)

    private var job: Job? = null
    private val transcriber = Transcriber(app)

    fun pick(uri: Uri?) {
        if (uri == null) return
        video = uri
        status = "Видео выбрано. Нажмите «Нарезать»"
        progress = 0f
    }

    fun cancel() {
        job?.cancel()
        status = "Отменено"
    }

    fun start() {
        val uri = video ?: return
        val ctx = getApplication<Application>()
        job = viewModelScope.launch {
            busy = true
            progress = 0f
            try {
                val durationSec = withContext(Dispatchers.IO) {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(ctx, uri)
                    val ms = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
                    r.release()
                    ms / 1000.0
                }

                var words = emptyList<Word>()
                if (subtitles) {
                    status = "Распознаю речь (первый запуск дольше)…"
                    words = withContext(Dispatchers.IO) {
                        transcriber.transcribe(uri, durationSec) { progress = it * 0.4f }
                    }
                }

                val clips = Planner.plan(durationSec, clipSec.toInt(), words)
                val base = if (subtitles) 0.4f else 0f
                clips.forEachIndexed { i, (s, e) ->
                    status = "Рендерю клип ${i + 1} из ${clips.size}…"
                    val tmp = File(ctx.cacheDir, "clip_${i + 1}.mp4").also { it.delete() }
                    val cues = if (subtitles) Planner.cues(words, s, e) else emptyList()
                    ClipExporter.export(ctx, uri, (s * 1000).toLong(), (e * 1000).toLong(), cues, tmp)
                    withContext(Dispatchers.IO) {
                        ClipExporter.saveToGallery(ctx, tmp, "reel_${System.currentTimeMillis()}_${i + 1}.mp4")
                    }
                    progress = base + (1f - base) * (i + 1) / clips.size
                }
                status = "Готово: ${clips.size} клипов в галерее (Movies/ReelsCutter)"
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                status = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }
}
