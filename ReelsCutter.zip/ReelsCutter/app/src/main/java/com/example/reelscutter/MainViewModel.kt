package com.example.reelscutter

import android.app.Application
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var settings by mutableStateOf(Prefs.load(app))
        private set
    var video by mutableStateOf<Uri?>(null)
    var videoName by mutableStateOf("")
    var bottomName by mutableStateOf("")
    var overlayName by mutableStateOf("")
    var ovFrame by mutableStateOf<Bitmap?>(null)
    var fonts by mutableStateOf(FontStore.list(app))
    var fontMsg by mutableStateOf("")
    var pending by mutableStateOf(false)
    var showBg by mutableStateOf(false)
    var startAfterBg by mutableStateOf(false)

    init {
        if (settings.bottomUri.isNotEmpty()) bottomName = nameOf(Uri.parse(settings.bottomUri))
        if (settings.overlayUri.isNotEmpty()) {
            val u = Uri.parse(settings.overlayUri)
            overlayName = nameOf(u)
            loadFrame(u, false)
        }
        refreshPending()
    }

    private fun nameOf(u: Uri) = getApplication<Application>().displayName(u)

    fun update(f: (Prefs.Settings) -> Prefs.Settings) {
        settings = f(settings)
        Prefs.save(getApplication(), settings)
    }

    private fun persist(uri: Uri) {
        try {
            getApplication<Application>().contentResolver
                .takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {}
    }

    fun pickMain(uri: Uri?) {
        if (uri == null) return
        persist(uri)
        video = uri
        videoName = nameOf(uri)
        JobState.status = "Видео выбрано. Нажмите «Нарезать»"
        JobState.progress = 0f
    }

    fun pickBottom(uri: Uri?) {
        if (uri == null) return
        persist(uri)
        bottomName = nameOf(uri)
        update { it.copy(bottomUri = uri.toString()) }
    }

    fun pickOverlay(uri: Uri?) {
        if (uri == null) return
        persist(uri)
        overlayName = nameOf(uri)
        update { it.copy(overlayUri = uri.toString()) }
        loadFrame(uri, true)
    }

    /** Кадр наложения для пипетки. Цвет фона берём из угла кадра. */
    private fun loadFrame(uri: Uri, autoKey: Boolean) {
        viewModelScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                val r = MediaMetadataRetriever()
                try {
                    r.setDataSource(getApplication<Application>(), uri)
                    r.getFrameAtTime(1_000_000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                } catch (_: Exception) {
                    null
                } finally {
                    r.release()
                }
            }
            ovFrame = bmp
            if (autoKey && bmp != null) {
                val c = bmp.getPixel(3.coerceAtMost(bmp.width - 1), 3.coerceAtMost(bmp.height - 1))
                update { it.copy(keyColor = c or 0xFF000000.toInt()) }
            }
        }
    }

    fun importFont(uri: Uri?) {
        if (uri == null) return
        viewModelScope.launch {
            try {
                val (item, warn) = withContext(Dispatchers.IO) { FontStore.import(getApplication(), uri) }
                fonts = FontStore.list(getApplication())
                update { it.copy(fontId = item.id) }
                fontMsg = if (warn.isEmpty()) "Шрифт «${item.label}» добавлен" else warn
            } catch (e: Exception) {
                fontMsg = e.message ?: "Не удалось добавить шрифт"
            }
        }
    }

    fun deleteFont(id: String) {
        FontStore.delete(getApplication(), id)
        fonts = FontStore.list(getApplication())
        if (settings.fontId == id) update { it.copy(fontId = "sys:bold") }
    }

    fun refreshPending() {
        pending = JobStore.load(getApplication()) != null && !JobState.busy
    }

    /** Проверка перед стартом. Возвращает текст ошибки или null. */
    fun validate(): String? {
        val s = settings
        if (video == null) return "Выберите видео"
        if (s.stacked && s.bottomUri.isEmpty()) return "Выберите видео для нижней части"
        if (s.overlay && s.overlayUri.isEmpty()) return "Выберите видео для наложения"
        if (s.subtitles && s.online && s.apiKey.isBlank()) return "Вставьте ключ API или выберите офлайн"
        return null
    }

    fun createJob() {
        JobStore.save(getApplication(), WorkJob(video.toString(), settings))
    }
}
