package com.example.reelscutter

import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

class MainViewModel : ViewModel() {
    var video by mutableStateOf<Uri?>(null)
    var clipSec by mutableStateOf(60f)
    var subtitles by mutableStateOf(true)

    fun pick(uri: Uri?) {
        if (uri == null) return
        video = uri
        JobState.status = "Видео выбрано. Нажмите «Нарезать»"
        JobState.progress = 0f
    }
}
