package com.example.reelscutter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Фоновая обработка видео. Задание хранится на диске (JobStore): если система убьёт процесс,
 * сервис перезапустится и продолжит с того клипа, на котором остановился.
 */
class ProcessingService : Service() {

    companion object {
        const val ACTION_START = "com.example.reelscutter.START"
        const val ACTION_CANCEL = "com.example.reelscutter.CANCEL"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val ID_PROGRESS = 1
        private const val ID_DONE = 2
        private const val MAX_ATTEMPTS = 4
    }

    private class Probe(val durSec: Double, val bitrate: Int, val w: Int, val h: Int)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var userCancelled = false
    private var timedOut = false
    private var lastPct = -1
    private var lastText = ""
    private lateinit var nm: NotificationManager

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Ход обработки", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Готово", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            userCancelled = true
            if (job?.isActive == true) {
                job?.cancel()
            } else {
                JobStore.clear(this)
                JobState.busy = false
                stopSelf()
            }
            return START_NOT_STICKY
        }

        // Старт из приложения или автоперезапуск системой (intent == null)
        if (!enterForeground()) {
            // Система не разрешила работать в фоне. Задание сохранено, продолжим из приложения.
            if (JobStore.load(this) != null) {
                doneNotification("Обработка прервана. Откройте приложение и нажмите «Продолжить».")
            }
            stopSelf()
            return START_NOT_STICKY
        }
        if (job?.isActive == true) return START_STICKY
        val wj = JobStore.load(this)
        if (wj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        userCancelled = false
        timedOut = false
        job = scope.launch { run(wj) }
        return START_STICKY
    }

    private fun enterForeground(): Boolean = try {
        startForeground(
            ID_PROGRESS,
            progressNotification("Запуск…", 0),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        true
    } catch (_: Exception) {
        false
    }

    /** Android 15: у фоновых сервисов типа dataSync есть лимит по времени. Сохраняем задание и останавливаемся. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        timedOut = true
        job?.cancel()
        stopSelf()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun run(wj: WorkJob) {
        JobState.busy = true
        JobState.error = ""
        lastPct = -1
        lastText = ""
        val wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ReelsCutter:work")
            .apply { acquire(6 * 60 * 60 * 1000L) }
        var finished = false
        try {
            wj.attempts++
            if (wj.attempts > MAX_ATTEMPTS) {
                throw IllegalStateException(
                    "Обработка несколько раз подряд прерывалась системой. " +
                        "Откройте «Настройки работы в фоне» в приложении и разрешите работу без ограничений."
                )
            }
            JobStore.save(this, wj)
            val st = wj.settings
            val source = Uri.parse(wj.source)

            report("Читаю видео…", 0f)
            if (wj.meta == null) {
                wj.meta = withContext(Dispatchers.IO) {
                    val m = probe(source)
                    val b = if (st.stacked && st.bottomUri.isNotEmpty()) probe(Uri.parse(st.bottomUri)) else null
                    val o = if (st.overlay && st.overlayUri.isNotEmpty()) probe(Uri.parse(st.overlayUri)) else null
                    Meta(m.durSec, m.bitrate, m.w, m.h, b?.durSec ?: 0.0, o?.durSec ?: 0.0, o?.w ?: 0, o?.h ?: 0)
                }
                JobStore.save(this, wj)
            }
            val meta = wj.meta!!

            // Распознавание речи
            if (st.subtitles && wj.words == null) {
                wj.words = withContext(Dispatchers.IO) { recognize(wj, source, meta) }
                JobStore.save(this, wj)
            }
            val words = if (st.subtitles) wj.words ?: emptyList() else emptyList()

            if (wj.clips == null) {
                wj.clips = Planner.plan(meta.durationSec, st.clipSec, words)
                JobStore.save(this, wj)
            }
            val clips = wj.clips!!

            val composite = st.stacked || st.overlay
            if (composite && !Advanced.available) {
                throw IllegalStateException(
                    "В этой сборке приложения нет режимов «видео снизу» и хромакея. " +
                        "Отключите их или соберите приложение заново (см. README)."
                )
            }
            if (st.stacked && st.bottomUri.isEmpty()) throw IllegalStateException("Не выбрано видео снизу")
            if (st.overlay && st.overlayUri.isEmpty()) throw IllegalStateException("Не выбрано видео для наложения")

            val frameW = if (st.stacked) 1080 else meta.width
            val frameH = if (st.stacked) 1920 else meta.height
            val topH = (frameH * st.topPct / 100) / 2 * 2
            val srcBitrate = (meta.bitrate * 1.3).toInt().coerceIn(6_000_000, 40_000_000)
            val bitrate = if (st.stacked) maxOf(10_000_000, srcBitrate.coerceAtMost(16_000_000)) else srcBitrate
            val typeface = FontStore.typeface(this, st.fontId)
            val textPx = (minOf(frameW, frameH) * st.sizePct / 100f).coerceAtLeast(24f)
            val pos = if (st.autoPos) (if (st.stacked) st.topPct + 3 else 72) else st.posPct
            val anchorY = 1f - 2f * pos / 100f

            var i = wj.done
            while (i < clips.size) {
                val (s, e) = clips[i]
                val base = i.toFloat() / clips.size
                val span = 1f / clips.size
                val label = "Клип ${i + 1} из ${clips.size}"
                report("$label: рендерю…", base)
                val tmp = File(cacheDir, "clip_${i + 1}.mp4").also { it.delete() }

                val cues = if (st.subtitles) Planner.cues(words, s, e) else emptyList()
                val subs = if (cues.isNotEmpty()) {
                    SubtitleOverlay(cues, typeface, textPx, Prefs.COLORS[st.colorIdx], (frameW * 0.9f).toInt(), anchorY)
                } else null

                val startMs = (s * 1000).toLong()
                val endMs = (e * 1000).toLong()
                val clipLen = e - s

                if (composite) {
                    val bot = segment(meta.bottomDurSec, clipLen, i)
                    val ov = segment(meta.ovDurSec, clipLen, i)
                    val ovW = ((frameW * st.ovSizePct / 100) / 2 * 2).coerceAtLeast(16)
                    val ratio = if (meta.ovWidth > 0 && meta.ovHeight > 0) meta.ovHeight.toDouble() / meta.ovWidth else 9.0 / 16
                    val ovH = ((ovW * ratio).toInt() / 2 * 2).coerceAtLeast(16)
                    val params = CompositeParams(
                        main = source, mainStartMs = startMs, mainEndMs = endMs,
                        outW = frameW, outH = frameH, stacked = st.stacked, topH = topH, fillTop = st.fill,
                        bottom = if (st.stacked) Uri.parse(st.bottomUri) else null,
                        bottomStartMs = bot.first, bottomEndMs = bot.second,
                        overlay = if (st.overlay) Uri.parse(st.overlayUri) else null,
                        ovStartMs = ov.first, ovEndMs = ov.second,
                        ovW = ovW, ovH = ovH,
                        ovAnchorX = st.ovX / 100f * 2f - 1f,
                        ovAnchorY = 1f - st.ovY / 100f * 2f,
                        chroma = st.chroma, keyColor = st.keyColor,
                        tolerance = st.tol, softness = st.soft, spill = st.spill,
                        subtitles = subs, bitrate = bitrate, out = tmp,
                    )
                    Advanced.exportComposite(applicationContext, params)
                } else if (subs != null) {
                    ClipExporter.export(applicationContext, source, startMs, endMs, subs, bitrate, tmp)
                } else {
                    // Без субтитров: нарезка без перекодирования (качество и размер не меняются)
                    try {
                        withContext(Dispatchers.IO) {
                            LosslessClipper.cut(
                                applicationContext, source, (s * 1_000_000).toLong(), (e * 1_000_000).toLong(), tmp,
                            ) { !isActive }
                        }
                    } catch (ex: CancellationException) {
                        throw ex
                    } catch (ex: Exception) {
                        tmp.delete()
                        report("$label: быстрая нарезка не вышла, перекодирую…", base)
                        ClipExporter.export(applicationContext, source, startMs, endMs, null, bitrate, tmp)
                    }
                }

                report("$label: сохраняю…", base + span * 0.95f)
                withContext(Dispatchers.IO) {
                    ClipExporter.saveToGallery(
                        applicationContext, tmp, "reel_${System.currentTimeMillis()}_${i + 1}.mp4",
                    )
                }
                i++
                wj.done = i
                wj.attempts = 1 // клип готов: прогресс есть, счётчик перезапусков обнуляем
                JobStore.save(this, wj)
            }

            var msg = "Готово: ${clips.size} клипов в галерее (Movies/ReelsCutter)"
            if (wj.warning.isNotEmpty()) msg += "\n" + wj.warning
            JobState.status = msg
            JobState.progress = 1f
            finished = true
            JobStore.clear(this)
            doneNotification(msg)
        } catch (e: CancellationException) {
            if (userCancelled) {
                JobStore.clear(this)
                JobState.status = "Отменено"
            } else if (timedOut) {
                JobState.status = "Остановлено системой. Нажмите «Продолжить»"
                doneNotification("Система остановила обработку. Откройте приложение и нажмите «Продолжить».")
            }
            // иначе процесс закрывается системой: задание остаётся на диске
            throw e
        } catch (e: Throwable) {
            finished = true
            JobStore.clear(this)
            val msg = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            JobState.status = msg
            JobState.error = errorText(e)
            doneNotification(msg)
        } finally {
            JobState.busy = false
            if (wakeLock.isHeld) wakeLock.release()
            if (finished || userCancelled || timedOut) {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    private fun errorText(e: Throwable): String {
        val sb = StringBuilder()
        var t: Throwable? = e
        var depth = 0
        while (t != null && depth < 4) {
            sb.append(t.javaClass.name).append(": ").append(t.message).append('\n')
            t.stackTrace.take(6).forEach { sb.append("   at ").append(it).append('\n') }
            t = t.cause
            depth++
        }
        return sb.toString()
    }

    /** Онлайн (если включено) с автоматическим переходом на офлайн при любой ошибке. */
    private fun recognize(wj: WorkJob, source: Uri, meta: Meta): List<Word> {
        val st = wj.settings
        val cancelled = { !job!!.isActive }
        if (st.online && st.apiKey.isNotBlank()) {
            try {
                return OnlineTranscriber(applicationContext).transcribe(
                    source, meta.durationSec, st.provider, st.apiKey, cancelled,
                ) { report("Распознаю речь через интернет…", it * 0.0f + 0f) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                wj.warning = "Онлайн-распознавание не сработало (${e.message}), использовано офлайн."
            }
        }
        return Transcriber(applicationContext).transcribe(source, meta.durationSec, cancelled) {
            report("Распознаю речь (первый запуск дольше)…", 0f)
        }
    }

    /** Кусок второго видео под клип с номером i. -1 в конце: брать целиком и зациклить. */
    private fun segment(durSec: Double, clipLen: Double, i: Int): Pair<Long, Long> {
        if (durSec <= clipLen + 2) return 0L to -1L
        val room = durSec - clipLen - 1
        val start = (i * clipLen) % room
        return (start * 1000).toLong() to ((start + clipLen) * 1000).toLong()
    }

    private fun probe(uri: Uri): Probe {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
                ?: error("Не удалось определить длину видео")
            val bitrate = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 8_000_000
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            return Probe(durationMs / 1000.0, bitrate, w, h)
        } finally {
            r.release()
        }
    }

    private fun report(text: String, progress: Float) {
        JobState.status = text
        JobState.progress = progress
        val pct = (progress * 100).toInt()
        if (pct != lastPct || text != lastText) {
            lastPct = pct
            lastText = text
            nm.notify(ID_PROGRESS, progressNotification(text, pct))
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun progressNotification(text: String, pct: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 1,
            Intent(this, ProcessingService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Reels Cutter")
            .setContentText(text)
            .setProgress(100, pct, false)
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Отмена",
                    cancel,
                ).build()
            )
            .build()
    }

    private fun doneNotification(text: String) {
        nm.notify(
            ID_DONE,
            Notification.Builder(this, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Reels Cutter")
                .setContentText(text)
                .setStyle(Notification.BigTextStyle().bigText(text))
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
        )
    }
}
