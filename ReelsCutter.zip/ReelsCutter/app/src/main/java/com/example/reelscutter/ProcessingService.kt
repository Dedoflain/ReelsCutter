package com.example.reelscutter

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.IBinder
import android.os.PowerManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/** Фоновая обработка видео: работает при свёрнутом приложении и выключенном экране. */
class ProcessingService : Service() {

    companion object {
        const val ACTION_START = "com.example.reelscutter.START"
        const val ACTION_CANCEL = "com.example.reelscutter.CANCEL"
        const val EXTRA_CLIP_SEC = "clip_sec"
        const val EXTRA_SUBTITLES = "subtitles"
        private const val CH_PROGRESS = "progress"
        private const val CH_DONE = "done"
        private const val ID_PROGRESS = 1
        private const val ID_DONE = 2
    }

    private data class Meta(val durationSec: Double, val bitrate: Int, val shortSide: Int)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var job: Job? = null
    private var lastPct = -1
    private var lastText = ""
    private lateinit var nm: NotificationManager
    private val transcriber by lazy { Transcriber(applicationContext) }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "Ход обработки", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Готово", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CANCEL -> {
                if (job?.isActive == true) job?.cancel() else stopSelf()
            }
            ACTION_START -> {
                // startForeground нужно вызвать сразу, иначе система остановит сервис
                startForeground(
                    ID_PROGRESS,
                    progressNotification("Запуск…", 0),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
                )
                val uri = intent.data
                if (uri == null || job?.isActive == true) {
                    if (uri == null) stopSelf()
                    return START_NOT_STICKY
                }
                val clipSec = intent.getIntExtra(EXTRA_CLIP_SEC, 60)
                val subtitles = intent.getBooleanExtra(EXTRA_SUBTITLES, true)
                job = scope.launch { run(uri, clipSec, subtitles) }
            }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    private suspend fun run(uri: Uri, clipSec: Int, subtitles: Boolean) {
        JobState.busy = true
        lastPct = -1
        lastText = ""
        val wakeLock = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ReelsCutter:work")
            .apply { acquire(6 * 60 * 60 * 1000L) }
        var saved = 0
        try {
            report("Читаю видео…", 0f)
            val meta = withContext(Dispatchers.IO) { readMeta(uri) }

            var words = emptyList<Word>()
            if (subtitles) {
                report("Распознаю речь (первый запуск дольше)…", 0f)
                words = withContext(Dispatchers.IO) {
                    transcriber.transcribe(uri, meta.durationSec, { !isActive }) {
                        report("Распознаю речь…", it * 0.4f)
                    }
                }
            }

            val clips = Planner.plan(meta.durationSec, clipSec, words)
            val base = if (subtitles) 0.4f else 0f
            // Битрейт чуть выше исходного, чтобы качество не падало
            val bitrate = (meta.bitrate * 1.3).toInt().coerceIn(6_000_000, 40_000_000)
            val textPx = (meta.shortSide * 0.06f).toInt().coerceAtLeast(24)

            clips.forEachIndexed { i, (s, e) ->
                report("Рендерю клип ${i + 1} из ${clips.size}…", base + (1f - base) * i / clips.size)
                val tmp = File(cacheDir, "clip_${i + 1}.mp4").also { it.delete() }
                val cues = if (subtitles) Planner.cues(words, s, e) else emptyList()
                ClipExporter.export(
                    applicationContext, uri, (s * 1000).toLong(), (e * 1000).toLong(),
                    cues, bitrate, textPx, tmp,
                )
                withContext(Dispatchers.IO) {
                    ClipExporter.saveToGallery(
                        applicationContext, tmp, "reel_${System.currentTimeMillis()}_${i + 1}.mp4",
                    )
                }
                saved++
            }
            val msg = "Готово: $saved клипов в галерее (Movies/ReelsCutter)"
            JobState.status = msg
            JobState.progress = 1f
            doneNotification(msg)
        } catch (e: CancellationException) {
            JobState.status = "Отменено"
            throw e
        } catch (e: Exception) {
            val msg = "Ошибка: ${e.message ?: e.javaClass.simpleName}"
            JobState.status = msg
            doneNotification(msg)
        } finally {
            JobState.busy = false
            if (wakeLock.isHeld) wakeLock.release()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun readMeta(uri: Uri): Meta {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(this, uri)
            val durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
            val bitrate = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull() ?: 8_000_000
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            return Meta(durationMs / 1000.0, bitrate, minOf(w, h))
        } finally {
            r.release()
        }
    }

    private fun report(text: String, progress: Float) {
        JobState.status = text
        JobState.progress = progress
        val pct = (progress * 100).toInt()
        if (pct != lastPct || text != lastText) {
            lastPct = pct
            lastText = text
            nm.notify(ID_PROGRESS, progressNotification(text, pct))
        }
    }

    private fun openAppIntent(): PendingIntent = PendingIntent.getActivity(
        this, 0,
        Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun progressNotification(text: String, pct: Int): Notification {
        val cancel = PendingIntent.getService(
            this, 1,
            Intent(this, ProcessingService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE,
        )
        return Notification.Builder(this, CH_PROGRESS)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("Reels Cutter")
            .setContentText(text)
            .setProgress(100, pct, false)
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Отмена",
                    cancel,
                ).build()
            )
            .build()
    }

    private fun doneNotification(text: String) {
        nm.notify(
            ID_DONE,
            Notification.Builder(this, CH_DONE)
                .setSmallIcon(android.R.drawable.stat_sys_download_done)
                .setContentTitle("Reels Cutter")
                .setContentText(text)
                .setContentIntent(openAppIntent())
                .setAutoCancel(true)
                .build()
        )
    }
}
