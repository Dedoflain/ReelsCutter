package com.example.reelscutter

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    // Разрешение на уведомления (Android 13+). Работа запускается в любом случае.
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { startWork() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Screen(vm, onStart = ::onStartClicked, onCancel = ::cancelWork)
                }
            }
        }
    }

    private fun onStartClicked() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startWork()
        }
    }

    private fun startWork() {
        val uri = vm.video ?: return
        if (JobState.busy) return
        JobState.busy = true
        JobState.progress = 0f
        JobState.status = "Запускаю…"
        val intent = Intent(this, ProcessingService::class.java)
            .setAction(ProcessingService.ACTION_START)
            .setData(uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putExtra(ProcessingService.EXTRA_CLIP_SEC, vm.clipSec.toInt())
            .putExtra(ProcessingService.EXTRA_SUBTITLES, vm.subtitles)
        startForegroundService(intent)
    }

    private fun cancelWork() {
        startService(Intent(this, ProcessingService::class.java).setAction(ProcessingService.ACTION_CANCEL))
    }
}

@Composable
private fun Screen(vm: MainViewModel, onStart: () -> Unit, onCancel: () -> Unit) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { vm.pick(it) }
    val busy = JobState.busy

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Reels Cutter", style = MaterialTheme.typography.headlineMedium)

        OutlinedButton(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.video == null) "Выбрать видео" else "Выбрать другое видео") }

        Text("Длина клипа: ${vm.clipSec.toInt()} сек")
        Slider(
            value = vm.clipSec,
            onValueChange = { vm.clipSec = it },
            valueRange = 15f..90f,
            steps = 14,
            enabled = !busy,
        )

        Row(
            Modifier.fillMaxWidth().clickable(enabled = !busy) { vm.subtitles = !vm.subtitles },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Checkbox(checked = vm.subtitles, onCheckedChange = { vm.subtitles = it }, enabled = !busy)
            Text(if (vm.subtitles) "Добавлять субтитры (русский, офлайн)" else "Без субтитров (быстро, без перекодирования)")
        }

        if (busy) {
            Button(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Отмена") }
        } else {
            Button(
                onClick = onStart,
                enabled = vm.video != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Нарезать") }
        }

        LinearProgressIndicator(progress = { JobState.progress }, modifier = Modifier.fillMaxWidth())
        Text(JobState.status)
        if (busy) Text("Можно свернуть приложение: обработка идёт в фоне, по окончании придёт уведомление.")
    }
}
