package com.example.reelscutter

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    // Разрешение на уведомления (Android 13+). Работа запускается в любом случае.
    private val notifPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { afterPermissions() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Screen(
                        vm,
                        onStart = ::onStartClicked,
                        onResume = ::resumeWork,
                        onCancel = ::cancelWork,
                        onBatteryExempt = ::requestBatteryExempt,
                        onAutostart = ::openAutostart,
                        onAppSettings = ::openAppSettings,
                    )
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refreshPending()
    }

    private fun onStartClicked() {
        val err = vm.validate()
        if (err != null) {
            JobState.status = err
            return
        }
        // Один раз предлагаем настроить работу в фоне
        if (!vm.settings.bgPrompted) {
            vm.update { it.copy(bgPrompted = true) }
            vm.startAfterBg = true
            vm.showBg = true
            return
        }
        afterBg()
    }

    private fun afterBg() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            afterPermissions()
        }
    }

    private fun afterPermissions() {
        if (JobState.busy) return
        vm.createJob()
        launchService()
    }

    private fun resumeWork() {
        if (JobState.busy) return
        launchService()
    }

    private fun launchService() {
        JobState.busy = true
        JobState.progress = 0f
        JobState.error = ""
        JobState.status = "Запускаю…"
        vm.pending = false
        startForegroundService(Intent(this, ProcessingService::class.java).setAction(ProcessingService.ACTION_START))
    }

    private fun cancelWork() {
        if (!JobState.busy) {
            JobStore.clear(this)
            vm.refreshPending()
            JobState.status = "Отменено"
            return
        }
        startService(Intent(this, ProcessingService::class.java).setAction(ProcessingService.ACTION_CANCEL))
    }

    fun continueAfterBgDialog() {
        vm.showBg = false
        if (vm.startAfterBg) {
            vm.startAfterBg = false
            afterBg()
        }
    }

    private fun requestBatteryExempt() {
        try {
            val pm = getSystemService(PowerManager::class.java)
            if (pm.isIgnoringBatteryOptimizations(packageName)) {
                JobState.status = "Ограничения батареи уже сняты"
                return
            }
            startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        } catch (_: Exception) {
            openAppSettings()
        }
    }

    private fun openAutostart() {
        try {
            startActivity(
                Intent().setComponent(
                    ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")
                )
            )
        } catch (_: Exception) {
            openAppSettings()
        }
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        )
    }
}

private fun parseArgb(c: Int) = Color(c)

@Composable
private fun Screen(
    vm: MainViewModel,
    onStart: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onBatteryExempt: () -> Unit,
    onAutostart: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val ctx = LocalContext.current
    val s = vm.settings
    val busy = JobState.busy
    val open = ActivityResultContracts.OpenDocument()
    val mainPicker = rememberLauncherForActivityResult(open) { vm.pickMain(it) }
    val bottomPicker = rememberLauncherForActivityResult(open) { vm.pickBottom(it) }
    val overlayPicker = rememberLauncherForActivityResult(open) { vm.pickOverlay(it) }
    val fontPicker = rememberLauncherForActivityResult(open) { vm.importFont(it) }
    val video = arrayOf("video/*")

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Text("Reels Cutter", style = MaterialTheme.typography.headlineMedium)

        if (vm.pending && !busy) {
            Surface(tonalElevation = 3.dp, shape = MaterialTheme.shapes.medium) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Есть незаконченная работа (её прервала система).")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = onResume) { Text("Продолжить") }
                        OutlinedButton(onClick = onCancel) { Text("Сбросить") }
                    }
                }
            }
        }

        OutlinedButton(
            onClick = { mainPicker.launch(video) }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.video == null) "Выбрать видео" else "Видео: ${vm.videoName}") }

        Text("Длина клипа: ${s.clipSec} сек")
        Slider(
            value = s.clipSec.toFloat(), onValueChange = { v -> vm.update { it.copy(clipSec = v.toInt()) } },
            valueRange = 15f..90f, steps = 14, enabled = !busy,
        )

        HorizontalDivider()
        Check("Видео снизу (как «СДВГ-видео»: игра, сабвей и т.п.)", s.stacked, !busy) { v -> vm.update { it.copy(stacked = v) } }
        if (s.stacked) {
            OutlinedButton(
                onClick = { bottomPicker.launch(video) }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            ) { Text(if (vm.bottomName.isEmpty()) "Выбрать нижнее видео" else "Снизу: ${vm.bottomName}") }
            Text("Основное видео занимает сверху: ${s.topPct}% кадра")
            Slider(
                value = s.topPct.toFloat(), onValueChange = { v -> vm.update { it.copy(topPct = v.toInt()) } },
                valueRange = 30f..70f, enabled = !busy,
            )
            Check("Заполнять кадр (края обрезаются)", s.fill, !busy) { v -> vm.update { it.copy(fill = v) } }
            Text(
                "Нижнее видео короче клипа — зацикливается, длиннее — берётся новый кусок на каждый клип. " +
                    "Размер итогового видео 1080×1920.",
                style = MaterialTheme.typography.bodySmall,
            )
        }

        HorizontalDivider()
        Check("Наложение видео поверх (хромакей)", s.overlay, !busy) { v -> vm.update { it.copy(overlay = v) } }
        if (s.overlay) {
            if (!Advanced.available) {
                Text("В этой сборке приложения нет хромакея. Пересоберите приложение (см. README).", color = MaterialTheme.colorScheme.error)
            }
            OutlinedButton(
                onClick = { overlayPicker.launch(video) }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            ) { Text(if (vm.overlayName.isEmpty()) "Выбрать видео для наложения" else "Наложение: ${vm.overlayName}") }
            Check("Убрать фон (хромакей)", s.chroma, !busy) { v -> vm.update { it.copy(chroma = v) } }
            val frame = vm.ovFrame
            if (s.chroma && frame != null) {
                Text("Коснитесь картинки в цвете фона, который нужно убрать:", style = MaterialTheme.typography.bodySmall)
                var box by remember { mutableStateOf(IntSize.Zero) }
                Image(
                    bitmap = frame.asImageBitmap(), contentDescription = null,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().height(180.dp)
                        .onSizeChanged { box = it }
                        .pointerInput(frame, box) {
                            detectTapGestures { p ->
                                // картинка вписана по центру: считаем реальную область
                                val scale = minOf(box.width.toFloat() / frame.width, box.height.toFloat() / frame.height)
                                val w = frame.width * scale
                                val h = frame.height * scale
                                val x = ((p.x - (box.width - w) / 2f) / scale).toInt()
                                val y = ((p.y - (box.height - h) / 2f) / scale).toInt()
                                if (x in 0 until frame.width && y in 0 until frame.height) {
                                    val c = frame.getPixel(x, y) or 0xFF000000.toInt()
                                    vm.update { it.copy(keyColor = c) }
                                }
                            }
                        },
                )
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Spacer(Modifier.size(28.dp).clip(CircleShape).background(parseArgb(s.keyColor)).border(1.dp, Color.Gray, CircleShape))
                    Text("Убираемый цвет")
                }
            }
            if (s.chroma) {
                Labeled("Сила (допуск): ${s.tol}", s.tol, 0..100, !busy) { v -> vm.update { it.copy(tol = v) } }
                Labeled("Мягкость краёв: ${s.soft}", s.soft, 0..100, !busy) { v -> vm.update { it.copy(soft = v) } }
                Labeled("Убрать зелёный отблеск: ${s.spill}", s.spill, 0..100, !busy) { v -> vm.update { it.copy(spill = v) } }
            }
            Labeled("Размер: ${s.ovSizePct}% ширины", s.ovSizePct, 10..100, !busy) { v -> vm.update { it.copy(ovSizePct = v) } }
            Labeled("Положение по горизонтали: ${s.ovX}%", s.ovX, 0..100, !busy) { v -> vm.update { it.copy(ovX = v) } }
            Labeled("Положение по вертикали: ${s.ovY}%", s.ovY, 0..100, !busy) { v -> vm.update { it.copy(ovY = v) } }
        }

        HorizontalDivider()
        Check(if (s.subtitles) "Субтитры (русский)" else "Без субтитров", s.subtitles, !busy) { v -> vm.update { it.copy(subtitles = v) } }
        if (s.subtitles) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = !s.online, onClick = { vm.update { it.copy(online = false) } }, enabled = !busy)
                Text("Офлайн (на телефоне)")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = s.online, onClick = { vm.update { it.copy(online = true) } }, enabled = !busy)
                Text("Через интернет (точнее, нужен ключ)")
            }
            if (s.online) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    RadioButton(selected = s.provider == "groq", onClick = { vm.update { it.copy(provider = "groq") } }, enabled = !busy)
                    Text("Groq (бесплатно)")
                    RadioButton(selected = s.provider == "openai", onClick = { vm.update { it.copy(provider = "openai") } }, enabled = !busy)
                    Text("OpenAI")
                }
                OutlinedTextField(
                    value = s.apiKey, onValueChange = { v -> vm.update { it.copy(apiKey = v.trim()) } },
                    label = { Text("Ключ API") }, singleLine = true, enabled = !busy,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
                Text("Если интернет или ключ не сработают, приложение само перейдёт на офлайн.", style = MaterialTheme.typography.bodySmall)
            }

            Text("Шрифт:")
            vm.fonts.forEach { f ->
                Row(
                    Modifier.fillMaxWidth().clickable(enabled = !busy) { vm.update { it.copy(fontId = f.id) } },
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    RadioButton(selected = s.fontId == f.id, onClick = { vm.update { it.copy(fontId = f.id) } }, enabled = !busy)
                    val tf = remember(f.id, vm.fonts) { FontStore.typeface(ctx, f.id) }
                    Text(f.label + " — Привет, мир", fontFamily = FontFamily(tf), fontSize = 18.sp, modifier = Modifier.weight(1f))
                    if (f.custom) TextButton(onClick = { vm.deleteFont(f.id) }, enabled = !busy) { Text("Удалить") }
                }
            }
            OutlinedButton(
                onClick = { fontPicker.launch(arrayOf("*/*")) }, enabled = !busy, modifier = Modifier.fillMaxWidth(),
            ) { Text("Добавить свой шрифт (.ttf / .otf)") }
            if (vm.fontMsg.isNotEmpty()) Text(vm.fontMsg, style = MaterialTheme.typography.bodySmall)

            Labeled("Размер текста: ${s.sizePct}", s.sizePct, 3..12, !busy) { v -> vm.update { it.copy(sizePct = v) } }
            Text("Цвет:")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Prefs.COLORS.forEachIndexed { i, c ->
                    Spacer(
                        Modifier.size(36.dp).clip(CircleShape).background(parseArgb(c))
                            .border(if (i == s.colorIdx) 3.dp else 1.dp, if (i == s.colorIdx) Color(0xFF3366FF) else Color.Gray, CircleShape)
                            .clickable(enabled = !busy) { vm.update { it.copy(colorIdx = i) } }
                    )
                }
            }
            Check("Положение текста выбрать автоматически", s.autoPos, !busy) { v -> vm.update { it.copy(autoPos = v) } }
            if (!s.autoPos) {
                Labeled("Положение сверху: ${s.posPct}%", s.posPct, 5..95, !busy) { v -> vm.update { it.copy(posPct = v) } }
            }
        }

        HorizontalDivider()
        if (busy) {
            Button(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Отмена") }
        } else {
            Button(onClick = onStart, enabled = vm.video != null, modifier = Modifier.fillMaxWidth()) { Text("Нарезать") }
        }
        OutlinedButton(onClick = { vm.showBg = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Настройки работы в фоне")
        }

        LinearProgressIndicator(progress = { JobState.progress }, modifier = Modifier.fillMaxWidth())
        Text(JobState.status)
        if (JobState.error.isNotEmpty()) {
            OutlinedButton(onClick = {
                val cm = ctx.getSystemService(ClipboardManager::class.java)
                cm.setPrimaryClip(ClipData.newPlainText("error", JobState.error))
                JobState.status = "Подробности ошибки скопированы. Отправьте их разработчику."
            }, modifier = Modifier.fillMaxWidth()) { Text("Скопировать подробности ошибки") }
        }
        if (busy) Text("Можно свернуть приложение: обработка идёт в фоне, по окончании придёт уведомление.")
        Spacer(Modifier.height(24.dp))
    }

    if (vm.showBg) {
        AlertDialog(
            onDismissRequest = { (ctx as MainActivity).continueAfterBgDialog() },
            title = { Text("Чтобы работало в фоне") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Телефон (особенно Xiaomi) может закрывать приложение при выключенном экране. Сделайте три вещи:\n" +
                            "1. Нажмите первую кнопку и разрешите «Без ограничений».\n" +
                            "2. Включите автозапуск для Reels Cutter.\n" +
                            "3. В списке недавних приложений потяните карточку вниз и нажмите замок."
                    )
                    OutlinedButton(onClick = onBatteryExempt, modifier = Modifier.fillMaxWidth()) { Text("1. Снять ограничения батареи") }
                    OutlinedButton(onClick = onAutostart, modifier = Modifier.fillMaxWidth()) { Text("2. Автозапуск (Xiaomi)") }
                    OutlinedButton(onClick = onAppSettings, modifier = Modifier.fillMaxWidth()) { Text("Настройки приложения") }
                }
            },
            confirmButton = { TextButton(onClick = { (ctx as MainActivity).continueAfterBgDialog() }) { Text("Готово") } },
        )
    }
}

@Composable
private fun Check(text: String, value: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(enabled = enabled) { onChange(!value) },
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Checkbox(checked = value, onCheckedChange = onChange, enabled = enabled)
        Text(text, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun Labeled(label: String, value: Int, range: IntRange, enabled: Boolean, onChange: (Int) -> Unit) {
    Column {
        Text(label)
        Slider(
            value = value.toFloat(), onValueChange = { onChange(it.toInt()) },
            valueRange = range.first.toFloat()..range.last.toFloat(), enabled = enabled,
        )
    }
}
