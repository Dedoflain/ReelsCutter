package com.example.reelscutter

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) // экран не гаснет во время рендера
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { Screen(vm) }
            }
        }
    }
}

@androidx.compose.runtime.Composable
private fun Screen(vm: MainViewModel) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { vm.pick(it) }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text("Reels Cutter", style = MaterialTheme.typography.headlineMedium)

        OutlinedButton(
            onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            enabled = !vm.busy,
            modifier = Modifier.fillMaxWidth(),
        ) { Text(if (vm.video == null) "Выбрать видео" else "Выбрать другое видео") }

        Text("Длина клипа: ${vm.clipSec.toInt()} сек")
        Slider(
            value = vm.clipSec,
            onValueChange = { vm.clipSec = it },
            valueRange = 15f..90f,
            steps = 14,
            enabled = !vm.busy,
        )

        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Switch(checked = vm.subtitles, onCheckedChange = { vm.subtitles = it }, enabled = !vm.busy)
            Text("Субтитры (русский, офлайн)")
        }

        if (vm.busy) {
            Button(onClick = { vm.cancel() }, modifier = Modifier.fillMaxWidth()) { Text("Отмена") }
        } else {
            Button(
                onClick = { vm.start() },
                enabled = vm.video != null,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Нарезать") }
        }

        LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
        Text(vm.status)
    }
}
