package com.example.reelscutter

import android.content.Context
import org.json.JSONObject

/** Все настройки приложения. Хранятся между запусками и сохраняются вместе с заданием. */
object Prefs {

    val COLORS = intArrayOf(
        0xFFFFFFFF.toInt(), // белый
        0xFFFFE600.toInt(), // жёлтый
        0xFF39FF14.toInt(), // зелёный
        0xFFFF3B3B.toInt(), // красный
        0xFF00E5FF.toInt(), // голубой
    )

    data class Settings(
        val clipSec: Int = 60,
        val subtitles: Boolean = true,
        val online: Boolean = false,
        val provider: String = "groq", // groq или openai
        val apiKey: String = "",
        val fontId: String = "sys:bold",
        val sizePct: Int = 6,          // высота текста, % от ширины кадра
        val colorIdx: Int = 0,
        val autoPos: Boolean = true,
        val posPct: Int = 72,          // положение центра текста, % сверху
        val stacked: Boolean = false,
        val bottomUri: String = "",
        val topPct: Int = 45,          // доля высоты под основное видео
        val fill: Boolean = true,      // заполнять кадр (с обрезкой) или вписывать целиком
        val bgPrompted: Boolean = false,
        val overlay: Boolean = false,
        val overlayUri: String = "",
        val chroma: Boolean = true,
        val keyColor: Int = 0xFF00B140.toInt(),
        val tol: Int = 35,
        val soft: Int = 12,
        val spill: Int = 30,
        val ovSizePct: Int = 45,       // ширина наложения, % от ширины кадра
        val ovX: Int = 50,             // центр наложения, % слева
        val ovY: Int = 78,             // центр наложения, % сверху
    ) {
        fun toJson(): JSONObject = JSONObject().apply {
            put("clipSec", clipSec); put("subtitles", subtitles); put("online", online)
            put("provider", provider); put("apiKey", apiKey); put("fontId", fontId)
            put("sizePct", sizePct); put("colorIdx", colorIdx); put("autoPos", autoPos)
            put("posPct", posPct); put("stacked", stacked); put("bottomUri", bottomUri)
            put("topPct", topPct); put("fill", fill); put("bgPrompted", bgPrompted)
            put("overlay", overlay); put("overlayUri", overlayUri); put("chroma", chroma)
            put("keyColor", keyColor); put("tol", tol); put("soft", soft); put("spill", spill)
            put("ovSizePct", ovSizePct); put("ovX", ovX); put("ovY", ovY)
        }

        companion object {
            fun fromJson(j: JSONObject): Settings {
                val d = Settings()
                return Settings(
                    clipSec = j.optInt("clipSec", d.clipSec),
                    subtitles = j.optBoolean("subtitles", d.subtitles),
                    online = j.optBoolean("online", d.online),
                    provider = j.optString("provider", d.provider),
                    apiKey = j.optString("apiKey", d.apiKey),
                    fontId = j.optString("fontId", d.fontId),
                    sizePct = j.optInt("sizePct", d.sizePct),
                    colorIdx = j.optInt("colorIdx", d.colorIdx).coerceIn(0, COLORS.size - 1),
                    autoPos = j.optBoolean("autoPos", d.autoPos),
                    posPct = j.optInt("posPct", d.posPct),
                    stacked = j.optBoolean("stacked", d.stacked),
                    bottomUri = j.optString("bottomUri", d.bottomUri),
                    topPct = j.optInt("topPct", d.topPct),
                    fill = j.optBoolean("fill", d.fill),
                    bgPrompted = j.optBoolean("bgPrompted", d.bgPrompted),
                    overlay = j.optBoolean("overlay", d.overlay),
                    overlayUri = j.optString("overlayUri", d.overlayUri),
                    chroma = j.optBoolean("chroma", d.chroma),
                    keyColor = j.optInt("keyColor", d.keyColor),
                    tol = j.optInt("tol", d.tol),
                    soft = j.optInt("soft", d.soft),
                    spill = j.optInt("spill", d.spill),
                    ovSizePct = j.optInt("ovSizePct", d.ovSizePct),
                    ovX = j.optInt("ovX", d.ovX),
                    ovY = j.optInt("ovY", d.ovY),
                )
            }
        }
    }

    private const val FILE = "settings"

    fun load(c: Context): Settings = try {
        Settings.fromJson(JSONObject(c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("json", "{}")!!))
    } catch (_: Exception) {
        Settings()
    }

    fun save(c: Context, s: Settings) {
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("json", s.toJson().toString()).apply()
    }
}
