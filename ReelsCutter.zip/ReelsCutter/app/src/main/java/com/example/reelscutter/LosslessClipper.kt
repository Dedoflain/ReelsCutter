package com.example.reelscutter

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import kotlinx.coroutines.CancellationException
import java.io.File
import java.nio.ByteBuffer

/**
 * Режет видео без перекодирования: копирует готовые кадры и звук в новый файл.
 * Качество и разрешение остаются точно такими же, работает очень быстро.
 * Начало клипа сдвигается к ближайшему ключевому кадру (обычно в пределах 1–2 секунд).
 */
object LosslessClipper {

    fun cut(
        context: Context,
        uri: Uri,
        startUs: Long,
        endUs: Long,
        out: File,
        isCancelled: () -> Boolean,
    ) {
        val ex = MediaExtractor()
        var mux: MediaMuxer? = null
        var muxStarted = false
        try {
            ex.setDataSource(context, uri, null)

            var vTrack = -1
            var aTrack = -1
            for (i in 0 until ex.trackCount) {
                val mime = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (vTrack < 0 && mime.startsWith("video/")) vTrack = i
                else if (aTrack < 0 && mime.startsWith("audio/")) aTrack = i
            }
            require(vTrack >= 0) { "В файле нет видеодорожки" }

            // Находим ближайший ключевой кадр к началу клипа
            ex.selectTrack(vTrack)
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_CLOSEST_SYNC)
            val base = ex.sampleTime
            require(base >= 0) { "Начало клипа за пределами видео" }

            if (aTrack >= 0) {
                ex.selectTrack(aTrack)
                ex.seekTo(base, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            }

            val vFormat = ex.getTrackFormat(vTrack)
            val rotation = if (vFormat.containsKey(MediaFormat.KEY_ROTATION)) {
                vFormat.getInteger(MediaFormat.KEY_ROTATION)
            } else 0

            mux = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            mux.setOrientationHint(rotation)
            val vOut = mux.addTrack(vFormat)
            var aOut = -1
            if (aTrack >= 0) {
                aOut = try {
                    mux.addTrack(ex.getTrackFormat(aTrack))
                } catch (e: Exception) {
                    -1 // формат звука не поддерживается в mp4: клип будет без звука
                }
            }
            mux.start()
            muxStarted = true

            val buf = ByteBuffer.allocate(8 * 1024 * 1024)
            val info = MediaCodec.BufferInfo()
            var written = 0
            while (true) {
                if (isCancelled()) throw CancellationException("cancelled")
                val track = ex.sampleTrackIndex
                if (track < 0) break
                val time = ex.sampleTime
                if (time > endUs + 3_000_000) break
                val outIdx = if (track == vTrack) vOut else aOut
                if (outIdx >= 0 && time >= base && time < endUs) {
                    buf.clear()
                    val size = ex.readSampleData(buf, 0)
                    if (size < 0) break
                    info.set(0, size, time - base, ex.sampleFlags)
                    mux.writeSampleData(outIdx, buf, info)
                    written++
                }
                ex.advance()
            }
            require(written > 0) { "Не удалось вырезать фрагмент" }
            muxStarted = false
            mux?.stop()
        } finally {
            try { if (muxStarted) mux?.stop() } catch (_: Exception) {}
            try { mux?.release() } catch (_: Exception) {}
            ex.release()
        }
    }
}
