package com.example.reelscutter

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Состояние работы. Живёт в процессе, поэтому его видят и сервис, и экран. */
object JobState {
    var status by mutableStateOf("Выберите видео")
    var progress by mutableStateOf(0f)
    var busy by mutableStateOf(false)
    var error by mutableStateOf("") // подробности последней ошибки, можно скопировать
}
