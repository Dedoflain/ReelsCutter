package com.example.reelscutter

import android.content.Context
import android.graphics.Paint
import android.graphics.Typeface
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File

/** Имя файла по Uri (для показа в интерфейсе). */
fun Context.displayName(uri: Uri): String = try {
    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
        if (c.moveToFirst()) c.getString(0) else null
    } ?: uri.lastPathSegment.orEmpty()
} catch (_: Exception) {
    uri.lastPathSegment.orEmpty()
}

/** Шрифты для субтитров: системные и добавленные пользователем (.ttf / .otf). */
object FontStore {

    data class Item(val id: String, val label: String, val custom: Boolean)

    private val builtin = listOf(
        Item("sys:bold", "Обычный жирный", false),
        Item("sys:black", "Очень жирный", false),
        Item("sys:condensed", "Узкий жирный", false),
        Item("sys:serif", "С засечками", false),
        Item("sys:mono", "Моноширинный", false),
        Item("sys:casual", "Рукописный", false),
    )

    private fun dir(c: Context) = File(c.filesDir, "fonts").also { it.mkdirs() }

    fun list(c: Context): List<Item> {
        val custom = dir(c).listFiles()
            ?.filter { it.isFile }
            ?.sortedBy { it.name.lowercase() }
            ?.map { Item("file:${it.name}", it.nameWithoutExtension, true) }
            ?: emptyList()
        return builtin + custom
    }

    fun typeface(c: Context, id: String): Typeface = try {
        when {
            id == "sys:black" -> Typeface.create("sans-serif-black", Typeface.NORMAL)
            id == "sys:condensed" -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            id == "sys:serif" -> Typeface.create("serif", Typeface.BOLD)
            id == "sys:mono" -> Typeface.create("monospace", Typeface.BOLD)
            id == "sys:casual" -> Typeface.create("casual", Typeface.NORMAL)
            id.startsWith("file:") -> {
                val f = File(dir(c), id.removePrefix("file:"))
                Typeface.Builder(f).build() ?: Typeface.create("sans-serif", Typeface.BOLD)
            }
            else -> Typeface.create("sans-serif", Typeface.BOLD)
        }
    } catch (_: Exception) {
        Typeface.create("sans-serif", Typeface.BOLD)
    }

    /** Добавляет шрифт. Возвращает (элемент, предупреждение) или бросает исключение с понятным текстом. */
    fun import(c: Context, uri: Uri): Pair<Item, String> {
        val name = c.displayName(uri).ifBlank { "font.ttf" }
        val ext = name.substringAfterLast('.', "").lowercase()
        require(ext in setOf("ttf", "otf", "ttc")) { "Нужен файл шрифта .ttf или .otf" }
        val safe = name.replace(Regex("[^\\p{L}\\p{N}._ -]"), "_")
        val target = File(dir(c), safe)
        c.contentResolver.openInputStream(uri)!!.use { i -> target.outputStream().use { o -> i.copyTo(o) } }

        val tf = Typeface.Builder(target).build()
        if (tf == null) {
            target.delete()
            throw IllegalArgumentException("Не удалось прочитать этот шрифт")
        }
        val hasCyr = Paint().apply { typeface = tf }.hasGlyph("Яя")
        val warn = if (hasCyr) "" else "В этом шрифте нет русских букв, субтитры будут некрасивыми."
        return Item("file:${target.name}", target.nameWithoutExtension, true) to warn
    }

    fun delete(c: Context, id: String) {
        if (id.startsWith("file:")) File(dir(c), id.removePrefix("file:")).delete()
    }
}
