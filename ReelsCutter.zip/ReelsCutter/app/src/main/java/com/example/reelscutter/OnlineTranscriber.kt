package com.example.reelscutter

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CancellationException
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Распознавание речи через интернет (Whisper). Нужен ключ API.
 * Работает с Groq (есть бесплатный лимит) и OpenAI. Звук отправляется кусками по 4 минуты.
 */
class OnlineTranscriber(private val context: Context) {

    private class ApiException(message: String) : IOException(message)

    companion object {
        private const val CHUNK_SEC = 240
        private const val BYTES_PER_SEC = 32000 // 16 кГц, моно, 16 бит
    }

    fun transcribe(
        uri: Uri,
        durationSec: Double,
        provider: String,
        apiKey: String,
        isCancelled: () -> Boolean,
        onProgress: (Float) -> Unit,
    ): List<Word> {
        require(apiKey.isNotBlank()) { "Не указан ключ API" }
        val (base, model) = if (provider == "openai") {
            "https://api.openai.com/v1" to "whisper-1"
        } else {
            "https://api.groq.com/openai/v1" to "whisper-large-v3-turbo"
        }

        val words = ArrayList<Word>()
        val buf = ByteArrayOutputStream()
        var sentBytes = 0L

        fun flush() {
            if (buf.size() == 0) return
            val pcm = buf.toByteArray()
            buf.reset()
            val offset = sentBytes.toDouble() / BYTES_PER_SEC
            words.addAll(send(base, model, apiKey.trim(), wav(pcm), offset, isCancelled))
            sentBytes += pcm.size
        }

        AudioDecoder.decode(context, uri) { pcm, ptsUs ->
            if (isCancelled()) throw CancellationException("cancelled")
            buf.write(pcm)
            if (buf.size() >= CHUNK_SEC * BYTES_PER_SEC) flush()
            onProgress((ptsUs / 1_000_000.0 / durationSec).coerceIn(0.0, 1.0).toFloat())
        }
        flush()
        return words
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(pcm.size + 44)
        fun int(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF); out.write((v shr 16) and 0xFF); out.write((v shr 24) and 0xFF) }
        fun short(v: Int) { out.write(v and 0xFF); out.write((v shr 8) and 0xFF) }
        out.write("RIFF".toByteArray()); int(36 + pcm.size); out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray()); int(16); short(1); short(1); int(16000); int(32000); short(2); short(16)
        out.write("data".toByteArray()); int(pcm.size)
        out.write(pcm)
        return out.toByteArray()
    }

    private fun multipart(boundary: String, model: String, wav: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(wav.size + 1024)
        fun field(name: String, value: String) {
            out.write("--$boundary\r\nContent-Disposition: form-data; name=\"$name\"\r\n\r\n$value\r\n".toByteArray())
        }
        field("model", model)
        field("response_format", "verbose_json")
        field("language", "ru")
        field("temperature", "0")
        field("timestamp_granularities[]", "word")
        out.write(
            ("--$boundary\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n" +
                "Content-Type: audio/wav\r\n\r\n").toByteArray()
        )
        out.write(wav)
        out.write("\r\n--$boundary--\r\n".toByteArray())
        return out.toByteArray()
    }

    private fun sleepCancellable(seconds: Double, isCancelled: () -> Boolean) {
        var left = (seconds * 1000).toLong()
        while (left > 0) {
            if (isCancelled()) throw CancellationException("cancelled")
            Thread.sleep(500)
            left -= 500
        }
    }

    private fun send(
        base: String, model: String, key: String, wav: ByteArray, offset: Double, isCancelled: () -> Boolean,
    ): List<Word> {
        val boundary = "----reels" + System.nanoTime()
        val body = multipart(boundary, model, wav)
        var attempt = 0
        while (true) {
            if (isCancelled()) throw CancellationException("cancelled")
            attempt++
            val conn = URL("$base/audio/transcriptions").openConnection() as HttpURLConnection
            try {
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 30_000
                conn.readTimeout = 300_000
                conn.setRequestProperty("Authorization", "Bearer $key")
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
                conn.setFixedLengthStreamingMode(body.size)
                conn.outputStream.use { it.write(body) }

                val code = conn.responseCode
                if (code in 200..299) {
                    return parse(conn.inputStream.bufferedReader().readText(), offset)
                }
                val err = conn.errorStream?.bufferedReader()?.readText().orEmpty()
                if (code == 401 || code == 403) throw ApiException("Неверный ключ API ($code)")
                if ((code == 429 || code >= 500) && attempt < 5) {
                    val wait = conn.getHeaderField("Retry-After")?.toDoubleOrNull() ?: (attempt * 8.0)
                    sleepCancellable(wait.coerceIn(2.0, 90.0), isCancelled)
                    continue
                }
                throw ApiException("Ошибка сервера $code: ${err.take(300)}")
            } catch (e: ApiException) {
                throw e
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                if (attempt >= 4) throw e
                sleepCancellable(5.0 * attempt, isCancelled)
            } finally {
                conn.disconnect()
            }
        }
    }

    private fun parse(text: String, offset: Double): List<Word> {
        val j = JSONObject(text)
        val result = ArrayList<Word>()
        val arr = j.optJSONArray("words")
        if (arr != null && arr.length() > 0) {
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val w = o.optString("word").trim()
                if (w.isNotEmpty()) result.add(Word(w, o.getDouble("start") + offset, o.getDouble("end") + offset))
            }
            return result
        }
        // Запасной вариант: слов с таймкодами нет, делим время сегмента между словами
        val segs = j.optJSONArray("segments") ?: return result
        for (i in 0 until segs.length()) {
            val s = segs.getJSONObject(i)
            val parts = s.optString("text").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (parts.isEmpty()) continue
            val start = s.getDouble("start")
            val len = s.getDouble("end") - start
            val total = parts.sumOf { it.length }.toDouble()
            var t = start
            for (p in parts) {
                val d = len * p.length / total
                result.add(Word(p, t + offset, t + d + offset))
                t += d
            }
        }
        return result
    }
}
