package com.example.reelscutter

import android.content.Context
import android.net.Uri
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.Size
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import java.lang.reflect.Proxy

/**
 * Составной клип: основное видео, под ним (по желанию) второе видео, поверх (по желанию)
 * наложение с вырезанным фоном. Всё склеивается в один кадр и кодируется аппаратным кодеком.
 */
object Advanced {
    const val available = true

    private enum class Role { MAIN, BOTTOM, OVERLAY }

    suspend fun exportComposite(context: Context, p: CompositeParams) {
        ClipExporter.runTransformer(context, p.bitrate) { transformer ->
            val roles = ArrayList<Role>()
            val sequences = ArrayList<EditedMediaItemSequence>()

            // Основное видео
            val mainEffects = ArrayList<Effect>()
            if (p.stacked) {
                mainEffects.add(
                    Presentation.createForWidthAndHeight(
                        p.outW,
                        p.topH,
                        if (p.fillTop) Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP else Presentation.LAYOUT_SCALE_TO_FIT,
                    )
                )
            }
            roles.add(Role.MAIN)
            sequences.add(sequence(item(p.main, p.mainStartMs, p.mainEndMs, false, mainEffects), false))

            // Видео снизу (звук убираем, чтобы не мешало)
            if (p.stacked && p.bottom != null) {
                val fx = listOf<Effect>(
                    Presentation.createForWidthAndHeight(
                        p.outW, p.outH - p.topH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP,
                    )
                )
                roles.add(Role.BOTTOM)
                sequences.add(sequence(item(p.bottom, p.bottomStartMs, p.bottomEndMs, true, fx), true))
            }

            // Наложение с хромакеем
            if (p.overlay != null) {
                val fx = ArrayList<Effect>()
                fx.add(Presentation.createForWidthAndHeight(p.ovW, p.ovH, Presentation.LAYOUT_SCALE_TO_FIT))
                if (p.chroma) fx.add(ChromaKeyEffect(p.keyColor, p.tolerance, p.softness, p.spill))
                roles.add(Role.OVERLAY)
                sequences.add(sequence(item(p.overlay, p.ovStartMs, p.ovEndMs, true, fx), true))
            }

            val builder = newCompositionBuilder(sequences)
            setCompositorSettings(builder, roles, p)
            val compositionEffects = ArrayList<Effect>()
            if (p.subtitles != null) {
                compositionEffects.add(OverlayEffect(listOf<TextureOverlay>(p.subtitles)))
            }
            builder.setEffects(Effects(listOf(), compositionEffects))
            transformer.start(builder.build(), p.out.absolutePath)
        }
    }

    private fun item(uri: Uri, startMs: Long, endMs: Long, removeAudio: Boolean, effects: List<Effect>): EditedMediaItem {
        val mediaItem = MediaItem.Builder().setUri(uri).apply {
            if (endMs > 0) {
                setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(startMs)
                        .setEndPositionMs(endMs)
                        .build()
                )
            }
        }.build()
        return EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(removeAudio)
            .setEffects(Effects(listOf(), effects))
            .build()
    }

    // Ниже: обращения к Media3 через рефлексию там, где у разных версий библиотеки отличаются
    // конструкторы и пакеты. Так одна и та же логика работает и в 1.5.x, и в более новых версиях.

    private fun sequence(item: EditedMediaItem, looping: Boolean): EditedMediaItemSequence {
        val cls = EditedMediaItemSequence::class.java
        try {
            return cls.getConstructor(List::class.java, Boolean::class.javaPrimitiveType)
                .newInstance(listOf(item), looping)
        } catch (_: NoSuchMethodException) {
            // в новых версиях конструкторы заменены фабриками и Builder
        }
        val base = cls.getMethod("withAudioAndVideoFrom", List::class.java).invoke(null, listOf(item))
        if (!looping) return base as EditedMediaItemSequence
        val up = base!!.javaClass.getMethod("buildUpon").invoke(base)!!
        val looped = up.javaClass.getMethod("setIsLooping", Boolean::class.javaPrimitiveType).invoke(up, true)!!
        return looped.javaClass.getMethod("build").invoke(looped) as EditedMediaItemSequence
    }

    private fun newCompositionBuilder(seqs: List<EditedMediaItemSequence>): Composition.Builder {
        val cls = Composition.Builder::class.java
        return try {
            cls.getConstructor(List::class.java).newInstance(seqs)
        } catch (_: NoSuchMethodException) {
            val rest = java.lang.reflect.Array.newInstance(EditedMediaItemSequence::class.java, seqs.size - 1)
            for (i in 1 until seqs.size) java.lang.reflect.Array.set(rest, i - 1, seqs[i])
            cls.getConstructor(EditedMediaItemSequence::class.java, rest.javaClass).newInstance(seqs[0], rest)
        }
    }

    private fun setCompositorSettings(builder: Composition.Builder, roles: List<Role>, p: CompositeParams) {
        val iface = listOf(
            "androidx.media3.common.VideoCompositorSettings",
            "androidx.media3.effect.VideoCompositorSettings",
            "androidx.media3.transformer.VideoCompositorSettings",
        ).firstNotNullOfOrNull { name ->
            try { Class.forName(name) } catch (_: ClassNotFoundException) { null }
        } ?: throw IllegalStateException("В этой версии Media3 не найден VideoCompositorSettings")

        val settings = Proxy.newProxyInstance(iface.classLoader, arrayOf(iface)) { proxy, method, args ->
            when (method.name) {
                "getOutputSize" -> Size(p.outW, p.outH)
                "getOverlaySettings" -> overlaySettings(roles.getOrElse(args[0] as Int) { Role.MAIN }, p)
                "hashCode" -> System.identityHashCode(proxy)
                "equals" -> proxy === args?.get(0)
                "toString" -> "ReelsCompositorSettings"
                else -> null
            }
        }
        val setter = Composition.Builder::class.java.methods
            .first { it.name == "setVideoCompositorSettings" && it.parameterTypes.size == 1 }
        setter.invoke(builder, settings)
    }

    private fun overlaySettings(role: Role, p: CompositeParams): OverlaySettings = when (role) {
        Role.MAIN ->
            if (p.stacked) {
                OverlaySettings.Builder().setOverlayFrameAnchor(0f, 1f).setBackgroundFrameAnchor(0f, 1f).build()
            } else {
                OverlaySettings.Builder().build()
            }
        Role.BOTTOM ->
            OverlaySettings.Builder().setOverlayFrameAnchor(0f, -1f).setBackgroundFrameAnchor(0f, -1f).build()
        Role.OVERLAY ->
            OverlaySettings.Builder().setOverlayFrameAnchor(0f, 0f)
                .setBackgroundFrameAnchor(p.ovAnchorX, p.ovAnchorY).build()
    }
}
