package com.example.reelscutter

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/**
 * Хромакей: убирает фон заданного цвета (обычно зелёный экран), делая его прозрачным.
 * tolerance, softness, spill: 0..100.
 */
class ChromaKeyEffect(
    private val keyColor: Int,
    private val tolerance: Int,
    private val softness: Int,
    private val spill: Int,
) : GlEffect {

    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        ChromaKeyProgram(keyColor, tolerance, softness, spill, useHdr)
}

private class ChromaKeyProgram(
    keyColor: Int,
    tolerance: Int,
    softness: Int,
    spill: Int,
    useHdr: Boolean,
) : BaseGlShaderProgram(useHdr, 1) {

    private val program = GlProgram(VERTEX, FRAGMENT)

    private val cb: Float
    private val cr: Float
    private val similarity = tolerance.coerceIn(0, 100) / 100f * 0.45f
    private val smooth = softness.coerceIn(0, 100) / 100f * 0.25f + 0.001f
    private val spillRange = spill.coerceIn(0, 100) / 100f * 0.3f

    init {
        val r = ((keyColor shr 16) and 0xFF) / 255f
        val g = ((keyColor shr 8) and 0xFF) / 255f
        val b = (keyColor and 0xFF) / 255f
        cb = -0.169f * r - 0.331f * g + 0.5f * b
        cr = 0.5f * r - 0.419f * g - 0.081f * b
        program.setBufferAttribute(
            "aFramePosition",
            GlUtil.getNormalizedCoordinateBounds(),
            GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE,
        )
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size = Size(inputWidth, inputHeight)

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        program.use()
        program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
        program.setFloatsUniform("uKeyCC", floatArrayOf(cb, cr))
        program.setFloatUniform("uSimilarity", similarity)
        program.setFloatUniform("uSmooth", smooth)
        program.setFloatUniform("uSpill", spillRange)
        program.bindAttributesAndUniforms()
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GlUtil.checkGlError()
    }

    override fun release() {
        super.release()
        program.delete()
    }

    private companion object {
        const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = vec2(aFramePosition.x * 0.5 + 0.5, aFramePosition.y * 0.5 + 0.5);
}
"""
        const val FRAGMENT = """
precision mediump float;
uniform sampler2D uTexSampler;
uniform vec2 uKeyCC;
uniform float uSimilarity;
uniform float uSmooth;
uniform float uSpill;
varying vec2 vTexSamplingCoord;
vec2 toCC(vec3 c) {
  return vec2(-0.169 * c.r - 0.331 * c.g + 0.5 * c.b, 0.5 * c.r - 0.419 * c.g - 0.081 * c.b);
}
void main() {
  vec4 c = texture2D(uTexSampler, vTexSamplingCoord);
  float d = distance(toCC(c.rgb), uKeyCC);
  float a = clamp((d - uSimilarity) / uSmooth, 0.0, 1.0);
  vec3 rgb = c.rgb;
  if (uSpill > 0.001) {
    float k = 1.0 - clamp((d - uSimilarity - uSmooth) / uSpill, 0.0, 1.0);
    float lum = dot(rgb, vec3(0.299, 0.587, 0.114));
    rgb = mix(rgb, vec3(lum), k);
  }
  gl_FragColor = vec4(rgb, c.a * a);
}
"""
    }
}
